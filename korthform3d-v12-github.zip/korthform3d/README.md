# Korthform3D

A simple 3D modeler for 3D printing that runs in the browser. Drag shapes onto a mat, turn some of them into holes, group them, and export an STL for your slicer.

The whole app is one file: `index.html`. There is no build step and nothing to install.

![Korthform3D with the sample design](docs/screenshot.png)

## Try it

- **Locally:** download `index.html` and open it in a current browser (Chrome, Edge, Firefox or Safari). It needs an internet connection the first time to load its libraries and fonts.
- **GitHub Pages:** in the repository settings, open Pages, choose "Deploy from a branch", and pick the `main` branch and `/ (root)` folder. The app is then served at `https://<user>.github.io/<repo>/`.

## Features

- **Shapes and holes.** Twelve basic shapes plus hole presets. Any shape can be a solid or a hole.
- **Group.** Combines solids and cuts the holes out of them. Ungroup gives the parts back.
- **Handles.** Resize, set height, lift off the mat and rotate, with snapping from 0.1 mm to 10 mm.
- **Dimension and constrain (K).** Click two shapes and keep a distance, flush faces, a shared center line or an equal size between them. Type a number on the model to move a part.
- **Dot shape tool (P).** Place dots and fill them into a solid, either wrapped or as an extruded outline with curved edges and rounded corners.
- **Screw maker.** ISO metric screws, tapped holes, clearance holes and nuts (M2 to M20) that share one thread and fit each other.
- **Files.** Binary STL export and import, and a `.korthform3d.json` design file. Export cuts loose holes into the parts they overlap and repairs the mesh.
- **Themes.** Twelve mat themes from the Theme button.
- **Also:** align, mirror, duplicate and repeat, copy and paste, lock, undo and redo, view cube, orthographic view, dark mode and a phone layout.

![Dimension between two shapes](docs/dimension.png)

![Some of the themes](docs/themes.png)

## Conventions

- Units are millimetres.
- Z is up, the same axes slicers use.
- The mat is 200 × 200 mm by default; set it to your printer's bed with Edit mat.

Press `?` in the app for the full list of mouse and keyboard shortcuts.

## Where your work is stored

Designs, the autosaved draft and the chosen theme are kept in your browser's local storage on your device. Nothing is uploaded. Clearing site data removes them, so use Export to keep a `.korthform3d.json` copy of anything you care about.

The file also contains optional hooks for a hosted viewer (`window.claude`). They do nothing when the page is opened from disk or from GitHub Pages.

## Libraries

Loaded at run time from the jsDelivr CDN, pinned to these versions. They are not copied into this repository.

| Library | Version | License |
| --- | --- | --- |
| [three.js](https://github.com/mrdoob/three.js) | 0.180.0 | MIT |
| [three-mesh-bvh](https://github.com/gkjohnson/three-mesh-bvh) | 0.9.15 | MIT |
| [three-bvh-csg](https://github.com/gkjohnson/three-bvh-csg) | 0.0.18 | MIT |

Fonts come from Google Fonts: Barlow, Barlow Semi Condensed and IBM Plex Mono (SIL Open Font License).

## Developing

Edit `index.html` directly. The script is one ES module, organized in sections in this order: helpers, shapes and geometry, CSG, document and history, renderer and mat, handles and pointer, shape library, dot tool, threads and screw maker, mesh repair, dimensions and constraints, inspector, actions, files, storage, keyboard, start-up.

For scripted tests, the page exposes a debug hook at `window.korthform3d` (the document, selection helpers, `buildSTL`, `addRel`, `setMatTheme` and more). Tests so far were run in headless Chrome with Playwright, serving the three npm packages locally in place of the CDN.

See [CHANGELOG.md](CHANGELOG.md) for version history.

## License

Copyright 2026 Kyleho.

Licensed under the [Apache License, Version 2.0](LICENSE). You may use, change and share Korthform3D, including commercially, as long as you:

- include a copy of the license,
- keep the copyright and attribution notices, including the [NOTICE](NOTICE) file, and
- state any significant changes you made.

The software is provided "as is", without warranty of any kind. See the license for the full terms.
