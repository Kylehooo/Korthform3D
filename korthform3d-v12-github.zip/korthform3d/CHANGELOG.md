# Changelog

Version numbers match the builds of `index.html`.

## v12 (2026-11-12)
- The app is now called Korthform3D. Designs and settings saved in the browser under the earlier name carry over, and earlier design files still open.
- Design files are now saved as `.korthform3d.json`.
- Released under the Apache License 2.0.

## v11 (2026-11-12)
- Renamed a theme to Air Glass.
- Added five themes: Pearl, Gold, Ice, Mocha, Graphite.

## v10 (2026-11-12)
- Theme button with a picker that stays open while you try themes.
- Added the Pay Dirt theme and a glassy sky-blue theme.
- Edit mat now only sets the mat size.

## v9 (2026-11-12)
- Mat color themes: Green, Dark, Tan, Light blue, Dark blue.

## v8 (2026-11-12)
- Dimension and constrain tool (K): distance, line up, shared center and same size between two shapes.
- Dimensions are drawn on the model, saved with the design and covered by undo.
- The file is now a complete standalone HTML document.

## v1 to v7 (through 2026-10-04)
- Core editor: shape library, holes, handles, align, mirror, duplicate, lock, view cube, dark mode, phone layout.
- Group and ungroup (solids minus holes).
- STL export and import, design files, saved designs.
- Dot shape tool with curves and rounded corners.
- Screw maker: ISO metric screws, tapped holes, clearance holes and nuts.
- Center on the mat, hole visibility and one-click cut.
